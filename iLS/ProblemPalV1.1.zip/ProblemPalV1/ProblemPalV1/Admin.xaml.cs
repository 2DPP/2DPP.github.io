﻿using System;
using System.Linq;
using System.Windows;
using System.Data.SqlClient;

namespace ProblemPalV1
{
    public partial class Admin : Window
    {
        private const string AdminUsername = "ProblemPalAdmin";
        private const string AdminPassword = "adminpassword";

        public Admin()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Text;

            if (username == AdminUsername && password == AdminPassword)
            {
                OpenAdminPanel();
            }
            else if (UserExists(username, password))
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            }
            else
            {
                LoginErrorText.Text = "Invalid username or password. Please try again.";
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Username and password cannot be empty. Please enter valid credentials.");
                return;
            }

            if (!UsernameExists(username))
            {
                RegisterUser(username, password);
                MessageBox.Show("User registered successfully.");
            }
            else
            {
                MessageBox.Show("Username already exists. Please choose a different one.");
            }
        }

        private bool UsernameExists(string username)
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT * FROM UserInfo WHERE Username = @Username", conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    return cmd.ExecuteReader().HasRows;
                }
            }
        }

        private bool UserExists(string username, string password)
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT * FROM UserInfo WHERE Username = @Username AND Password = @Password", conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    return cmd.ExecuteReader().HasRows;
                }
            }
        }

        private void RegisterUser(string username, string password)
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("INSERT INTO UserInfo (Username, Password) VALUES (@Username, @Password)", conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void DeleteAllUsers()
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("DELETE FROM [C:\\USERS\\JOHN ANDREW CATUBAG\\ONEDRIVE\\DESKTOP\\PROBLEMPALV1\\PROBLEMPALV1\\BIN\\DEBUG\\NET8.0-WINDOWS7.0\\PROBLEMPAL.MDF].[dbo].[UserInfo]", conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void OpenAdminPanel()
        {
            var adminPanel = Application.Current.Windows.OfType<Admin>().FirstOrDefault();

            if (adminPanel == null)
            {
                adminPanel = new Admin();
                adminPanel.Show();
            }
            else
            {
                adminPanel.Focus();
            }

            AdminWindow adminWindow = new AdminWindow();
            adminWindow.Show();

            Close();
        }
    }
}
