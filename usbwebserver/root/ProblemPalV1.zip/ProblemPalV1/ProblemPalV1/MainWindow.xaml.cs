﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
namespace ProblemPalV1
{
    public partial class MainWindow : Window
    {   
     
        // Dictionaries to store like and dislike counts for each post
        private Dictionary<StackPanel, int> likeCounts = new Dictionary<StackPanel, int>();
        private Dictionary<StackPanel, int> dislikeCounts = new Dictionary<StackPanel, int>();

        public MainWindow()
        {
            InitializeComponent();
            LoadComplaints();
        }

        // Event handler for the "Post" button click
        private void Post_Click(object sender, RoutedEventArgs e)
        {
            
            string complaintText = Complaint.Text;

            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("INSERT INTO Complaints (ComplaintText, Status) VALUES (@ComplaintText, 'Pending')", conn))
                {
                    cmd.Parameters.AddWithValue("@ComplaintText", complaintText);
                    cmd.ExecuteNonQuery();
                }
            }

            
            LoadComplaints();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadComplaints();
        }


        private void LoadComplaints()
        {

            List<ComplaintItem> approvedComplaints = GetApprovedComplaints();

            
            ComplaintsListBox.ItemsSource = approvedComplaints;
        }

        private List<ComplaintItem> GetApprovedComplaints()
        {
            List<ComplaintItem> approvedComplaints = new List<ComplaintItem>();

            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();

                using (var cmd = new SqlCommand("SELECT ComplaintText, Status FROM Complaints WHERE Status = 'Approved'", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        
                        approvedComplaints.Add(new ComplaintItem
                        {
                            ComplaintText = reader["ComplaintText"].ToString(),
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            return approvedComplaints;
        }
        public class ComplaintItem
        {
            public string ComplaintText { get; set; }
            public string Status { get; set; }
        }



        // Event handler to show rules popup
        private void ShowRules_Click(object sender, RoutedEventArgs e)
        {
            RulesPopup.IsOpen = true;
        }

        // Event handler for agreeing to rules
        private void IAgree_Click(object sender, RoutedEventArgs e)
        {
            RulesPopup.IsOpen = false;
        }

        // Event handler to show contacts
        private void ShowContacts_Click(object sender, RoutedEventArgs e)
        {
            Contact.IsOpen = true;
        }

        // Event handler to close contacts
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Contact.IsOpen = false;
        }

        private void OpenAdmin_Click(object sender, RoutedEventArgs e)
        {
            // Open the AdminPanelWindow
            Admin adminPanel = new Admin();
            adminPanel.Show();
        }

        private void LikeButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var complaint = (ComplaintItem)button.DataContext;
            LikeComplaint(complaint);
        }

        private void DislikeButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var complaint = (ComplaintItem)button.DataContext;
            DislikeComplaint(complaint);
        }

        private void LikeComplaint(ComplaintItem complaint)
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();

                using (var cmd = new SqlCommand("UPDATE Complaints SET Likes = Likes + 1 WHERE ComplaintText = @ComplaintText", conn))
                {
                    cmd.Parameters.AddWithValue("@ComplaintText", complaint.ComplaintText);
                    cmd.ExecuteNonQuery();
                }
            }

            LoadComplaints(); 
        }

        private void DislikeComplaint(ComplaintItem complaint)
        {
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();

                using (var cmd = new SqlCommand("UPDATE Complaints SET Dislikes = Dislikes + 1 WHERE ComplaintText = @ComplaintText", conn))
                {
                    cmd.Parameters.AddWithValue("@ComplaintText", complaint.ComplaintText);
                    cmd.ExecuteNonQuery();
                }
            }

            LoadComplaints(); 
        }

    }
}
