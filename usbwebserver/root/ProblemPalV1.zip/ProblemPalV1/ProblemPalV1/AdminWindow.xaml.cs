﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Data.SqlClient;

namespace ProblemPalV1
{
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
            LoadComplaints(); 
        }

        private void LoadComplaints()
        {
            // Retrieve complaints from the database
            List<ComplaintItem> complaints = GetComplaints();

            // Display the complaints in a ListBox
            ComplaintsListBox.ItemsSource = complaints;
        }

        private List<ComplaintItem> GetComplaints()
        {
            List<ComplaintItem> complaints = new List<ComplaintItem>();

            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();

                using (var cmd = new SqlCommand("SELECT ComplaintText, Status FROM Complaints", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Add each complaint to the list
                        complaints.Add(new ComplaintItem
                        {
                            ComplaintText = reader["ComplaintText"].ToString(),
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            return complaints;
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadComplaints();
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var complaint = (ComplaintItem)button.DataContext;
            ApproveComplaint(complaint);
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var complaint = (ComplaintItem)button.DataContext;
            DeleteComplaint(complaint);
        }

        private void ApproveComplaint(ComplaintItem complaint)
        {
            UpdateComplaintStatus(complaint, "Approved");
            LoadComplaints(); 
            MessageBox.Show("Complaint approved!");
        }

        private void DeleteComplaint(ComplaintItem complaint)
        {
            UpdateComplaintStatus(complaint, "Denied");
            LoadComplaints(); 
            MessageBox.Show("Complaint denied!");
        }

        private void UpdateComplaintStatus(ComplaintItem complaint, string status)
        {
         
            using (var conn = new SqlConnection(SQL_Information.ConnectionString))
            {
                conn.Open();

                using (var cmd = new SqlCommand("UPDATE Complaints SET Status = @Status WHERE ComplaintText = @ComplaintText", conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@ComplaintText", complaint.ComplaintText);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public class ComplaintItem
        {
            public string ComplaintText { get; set; }
            public string Status { get; set; }
        }
    }

}