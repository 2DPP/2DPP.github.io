Go to: \ProblemPalV1\ProblemPalV1\bin\Debug\net8.0-windows7.0
and  OPEN "ProblemPalv1.exe" to start 

or open "ProblemPalV1 shortcut"

Note: Open .exe  file (Application) not .sln file (Visual Studio Solution)

if app is not opening, just make another shortcut of the .exe file
